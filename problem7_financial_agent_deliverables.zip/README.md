# Problem 7: Autonomous Financial Analyst Agent

## Objective
Demonstrate an agent workflow that calls custom tools to retrieve
portfolio information, search market research, and perform calculations.

## Tools
1. SQL portfolio tool backed by SQLite.
2. Market RAG tool using TF-IDF retrieval over a PDF.
3. Restricted arithmetic calculator.

## Agent workflow
Question -> SQL action/observation -> market retrieval action/observation
-> calculation action/observation -> final report.

## Outputs
- financial_analysis_report.json
- financial_analysis_report.pdf
- agent_trace_log.json
- agent_test_results.csv
- agent_trace_chart.png

## Limitations
This version uses a deterministic Python controller, not an LLM.
The portfolio and market report data are synthetic.
The calculated balance-times-tax-rate amount is illustrative only
and is not an estimate of actual tax liability.
