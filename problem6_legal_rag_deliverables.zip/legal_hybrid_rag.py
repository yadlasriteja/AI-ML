
from pathlib import Path
import re
import json
import argparse

import chromadb
from pypdf import PdfReader
from rank_bm25 import BM25Okapi
from sentence_transformers import SentenceTransformer, CrossEncoder

BASE = Path(__file__).resolve().parent
DOCS = BASE / "contracts"
DB = BASE / "chroma_db"

EMBED_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
RERANK_MODEL = "cross-encoder/ms-marco-MiniLM-L-6-v2"


def tokenize(text):
    return re.findall(r"[a-z0-9]+(?:\\.[0-9]+)*", text.lower())


def parse_file(path):
    if path.suffix.lower() == ".txt":
        text = path.read_text(encoding="utf-8")
    elif path.suffix.lower() == ".pdf":
        reader = PdfReader(str(path))
        text = "\\n".join(page.extract_text() or "" for page in reader.pages)
    else:
        return []

    parts = re.split(
        r"(?=Clause\\s+\\d+(?:\\.\\d+)*\\s*[-–:])",
        text,
        flags=re.IGNORECASE
    )
    output = []

    for part in parts:
        part = part.strip()
        if not part:
            continue
        match = re.match(
            r"(Clause\\s+\\d+(?:\\.\\d+)*\\s*[-–:]\\s*[^\\n]+)",
            part,
            flags=re.IGNORECASE
        )
        output.append({
            "source": path.name,
            "clause": match.group(1).strip() if match else part.splitlines()[0][:120],
            "text": part
        })
    return output


def build_index():
    docs = []
    for path in sorted(DOCS.iterdir()):
        if path.suffix.lower() in {".txt", ".pdf"}:
            docs.extend(parse_file(path))

    if not docs:
        raise RuntimeError(f"No TXT or PDF contracts found in {DOCS}")

    embedding_model = SentenceTransformer(EMBED_MODEL)
    vectors = embedding_model.encode(
        [d["text"] for d in docs],
        normalize_embeddings=True,
        convert_to_numpy=True,
        show_progress_bar=True
    )

    client = chromadb.PersistentClient(path=str(DB))
    try:
        client.delete_collection("legal_contract_chunks")
    except Exception:
        pass

    collection = client.create_collection(
        "legal_contract_chunks",
        metadata={"hnsw:space": "cosine"}
    )
    collection.add(
        ids=[f"clause_{i}" for i in range(len(docs))],
        documents=[d["text"] for d in docs],
        metadatas=[{
            "source": d["source"],
            "clause": d["clause"],
            "doc_index": str(i)
        } for i, d in enumerate(docs)],
        embeddings=vectors.tolist()
    )

    print(f"Indexed {len(docs)} clauses.")
    return docs


def answer_query(query, docs):
    embedding_model = SentenceTransformer(EMBED_MODEL)
    reranker = CrossEncoder(RERANK_MODEL)
    client = chromadb.PersistentClient(path=str(DB))
    collection = client.get_collection("legal_contract_chunks")

    bm25 = BM25Okapi([tokenize(d["text"]) for d in docs])

    # BM25 rankings
    scores = bm25.get_scores(tokenize(query))
    keyword_order = sorted(range(len(docs)), key=lambda i: scores[i], reverse=True)[:8]

    # Vector rankings
    query_vector = embedding_model.encode(
        [query], normalize_embeddings=True, convert_to_numpy=True
    )[0].tolist()
    vector_results = collection.query(
        query_embeddings=[query_vector],
        n_results=min(8, len(docs)),
        include=["metadatas"]
    )
    vector_order = [
        int(m["doc_index"]) for m in vector_results["metadatas"][0]
    ]

    # Reciprocal Rank Fusion
    fused = {}
    for order in [keyword_order, vector_order]:
        for rank, idx in enumerate(order, 1):
            fused[idx] = fused.get(idx, 0.0) + 1 / (60 + rank)

    candidates = sorted(fused, key=fused.get, reverse=True)[:8]
    pairs = [(query, docs[i]["text"]) for i in candidates]
    cross_scores = reranker.predict(pairs)
    reranked = sorted(
        zip(candidates, cross_scores),
        key=lambda x: float(x[1]),
        reverse=True
    )[:3]

    evidence = []
    for idx, score in reranked:
        d = docs[idx]
        evidence.append({
            "source": d["source"],
            "clause": d["clause"],
            "score": float(score),
            "text": d["text"]
        })

    return {
        "query": query,
        "answer": (
            "Retrieved evidence only; review the cited contract text "
            "before drawing a legal conclusion."
        ),
        "evidence": evidence
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--rebuild", action="store_true")
    parser.add_argument(
        "--query",
        default="Which clause limits aggregate liability?"
    )
    args = parser.parse_args()

    if args.rebuild:
        docs = build_index()
    else:
        docs = []
        for path in sorted(DOCS.iterdir()):
            if path.suffix.lower() in {".txt", ".pdf"}:
                docs.extend(parse_file(path))

    result = answer_query(args.query, docs)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
