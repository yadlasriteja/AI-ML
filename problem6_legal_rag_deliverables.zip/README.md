# Problem 6: Production Legal Contract Q&A

## Objective
Build a hybrid retrieval pipeline for legal contract search.

## Pipeline components
1. Contract PDF and TXT parsing.
2. Clause-aware text segmentation.
3. BM25 keyword retrieval.
4. Dense vector retrieval using sentence-transformers/all-MiniLM-L6-v2.
5. Reciprocal Rank Fusion (RRF).
6. Cross-encoder re-ranking using cross-encoder/ms-marco-MiniLM-L-6-v2.
7. Evidence passages with source and clause citations.
8. Precision@3 and Recall@3 retrieval benchmarks.

## Dataset
Synthetic educational contracts. These are not real legal agreements.

## Evaluation
See:
- outputs/retrieval_benchmark.csv
- outputs/benchmark_summary.csv
- outputs/retrieval_benchmark.png

Metrics are calculated against manually labeled relevant clauses.
They are demonstration benchmarks, not evidence of legal-grade accuracy.

## Deliverables
- legal_hybrid_rag.py
- contracts/
- chroma_db/
- outputs/parsed_contract_clauses.csv
- outputs/retrieval_benchmark.csv
- outputs/benchmark_summary.csv
- outputs/retrieval_benchmark.png
- README.md

## Limitations
The notebook returns retrieved evidence rather than a synthesized
LLM-generated legal answer. A production deployment needs a validated
LLM integration, strict citation checking, access control, security
testing, document versioning, and review by qualified legal professionals.
