# Clinical Monitoring Manual

## Vital Signs
Vital signs include temperature, heart rate, respiratory rate,
blood pressure, and oxygen saturation. Record measurements with
their timestamps and relevant context.

## Monitoring Escalation
A change from a patient's documented baseline should be reviewed
in context. Follow the organization's approved escalation protocol.
Seek qualified clinical review when a concerning change is observed.

## Documentation
Record observations accurately and promptly. Include the time,
measurement, relevant symptoms, and actions taken.
