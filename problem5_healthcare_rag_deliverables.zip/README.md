# Problem 5: Healthcare Clinical Manual Ingestion and RAG Pipeline

## Objective
Build a multi-format document ingestion and vector retrieval pipeline.

## Input formats
- PDF
- Markdown
- Plain text

## Processing
1. Parse documents and retain source and section metadata.
2. Generate fixed-size chunks (500 characters, 100 overlap).
3. Generate header-based chunks from parsed sections.
4. Generate embeddings using sentence-transformers/all-MiniLM-L6-v2.
5. Store embeddings in persistent ChromaDB collections.
6. Retrieve top-k relevant chunks using cosine similarity.
7. Compare the chunking strategies with a keyword-based recall@3 proxy.

## Collections
- clinical_fixed_chunks
- clinical_header_chunks

## Results from this run
- Parsed sections: 8
- Fixed-size chunks: 8
- Header-based chunks: 8

See outputs/chunking_strategy_comparison.csv for the measured
comparison and outputs/chunking_comparison.png for the chart.

## Deliverables
- healthcare_rag_ingestion.py
- documents/
- chroma_db/
- outputs/parsed_document_sections.csv
- outputs/chunking_evaluation.csv
- outputs/chunking_strategy_comparison.csv
- outputs/chunking_comparison.png
- outputs/sample_retrieval_results.csv
- outputs/ingestion_manifest.json

## Limitations
The example documents are synthetic educational content, not approved
clinical guidance. The evaluation is a simple keyword-based proxy,
not a validated clinical benchmark. This project retrieves passages
but does not generate or validate medical answers. Scanned PDFs need
OCR. Production deployment requires approved documents, privacy and
access controls, monitoring, and clinical review.
