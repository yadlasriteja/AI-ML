
from pathlib import Path
import re
import chromadb
from pypdf import PdfReader
from sentence_transformers import SentenceTransformer

BASE = Path(__file__).resolve().parent
DOCS = BASE / "documents"
DB = BASE / "chroma_db"
MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

def parse_file(path):
    rows = []

    if path.suffix.lower() == ".md":
        heading = "Introduction"
        buffer = []

        def save():
            text = "\n".join(buffer).strip()
            if text:
                rows.append({
                    "source": path.name,
                    "heading": heading,
                    "page": "",
                    "text": text
                })

        for line in path.read_text(encoding="utf-8").splitlines():
            if line.startswith("#"):
                save()
                heading = re.sub(r"^#+\s*", "", line).strip()
                buffer = []
            else:
                buffer.append(line)
        save()

    elif path.suffix.lower() == ".txt":
        text = path.read_text(encoding="utf-8")
        for i, block in enumerate(re.split(r"\n\s*\n", text), 1):
            block = block.strip()
            if block:
                rows.append({
                    "source": path.name,
                    "heading": block.splitlines()[0][:100],
                    "page": "",
                    "text": block
                })

    elif path.suffix.lower() == ".pdf":
        reader = PdfReader(str(path))
        for page_no, page in enumerate(reader.pages, 1):
            text = (page.extract_text() or "").strip()
            if text:
                rows.append({
                    "source": path.name,
                    "heading": f"PDF page {page_no}",
                    "page": page_no,
                    "text": text
                })

    return rows

def fixed_chunks(sections, size=500, overlap=100):
    chunks = []
    for section in sections:
        text = section["text"]
        start = 0
        while start < len(text):
            end = min(start + size, len(text))
            piece = text[start:end].strip()
            if piece:
                chunks.append({**section, "text": piece})
            if end == len(text):
                break
            start = end - overlap
    return chunks

def header_chunks(sections):
    return [
        {**s, "text": s["text"].strip()}
        for s in sections if s["text"].strip()
    ]

def store(client, name, chunks, vectors):
    try:
        client.delete_collection(name)
    except Exception:
        pass

    collection = client.create_collection(
        name=name, metadata={"hnsw:space": "cosine"}
    )

    for start in range(0, len(chunks), 5000):
        end = min(start + 5000, len(chunks))
        batch = chunks[start:end]
        collection.add(
            ids=[f"{name}_{i}" for i in range(start, end)],
            documents=[c["text"] for c in batch],
            metadatas=[{
                "source": str(c.get("source", "")),
                "heading": str(c.get("heading", "")),
                "page": str(c.get("page", ""))
            } for c in batch],
            embeddings=vectors[start:end].tolist()
        )
    return collection

def main():
    DOCS.mkdir(parents=True, exist_ok=True)
    DB.mkdir(parents=True, exist_ok=True)

    sections = []
    for path in sorted(DOCS.iterdir()):
        if path.suffix.lower() in {".md", ".txt", ".pdf"}:
            sections.extend(parse_file(path))

    if not sections:
        raise RuntimeError(f"No supported documents found in {DOCS}")

    fixed = fixed_chunks(sections)
    headed = header_chunks(sections)

    model = SentenceTransformer(MODEL_NAME)
    fixed_vectors = model.encode(
        [c["text"] for c in fixed],
        normalize_embeddings=True,
        convert_to_numpy=True,
        show_progress_bar=True
    )
    headed_vectors = model.encode(
        [c["text"] for c in headed],
        normalize_embeddings=True,
        convert_to_numpy=True,
        show_progress_bar=True
    )

    client = chromadb.PersistentClient(path=str(DB))
    c1 = store(client, "clinical_fixed_chunks", fixed, fixed_vectors)
    c2 = store(client, "clinical_header_chunks", headed, headed_vectors)

    print("Parsed sections:", len(sections))
    print("Fixed-size chunks:", c1.count())
    print("Header-based chunks:", c2.count())
    print("ChromaDB location:", DB)

if __name__ == "__main__":
    main()
