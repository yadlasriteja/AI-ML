# Problem 8: Multi-Agent DevSecOps Code Audit

## Objective
Demonstrate a workflow of specialized agents that scan code,
propose a security patch, validate the patch, and record an audit log.

## Agents
1. Security Scanner Agent
2. Remediation Agent
3. Code Reviewer / QA Agent

## Workflow
Code input -> Security findings -> Patch proposal -> QA validation
-> Accept or reject patch -> Audit log

## Outputs
- Patched Python source
- security_audit_log.json
- security_audit_log.csv
- qa_validation_chart.png

## Limitations
This is a deterministic educational prototype, not a full LLM-based
CrewAI or LangGraph implementation. The scanner detects only selected
patterns. QA checks syntax and a targeted SQL parameterization criterion.
Review all patches before using them in production.
